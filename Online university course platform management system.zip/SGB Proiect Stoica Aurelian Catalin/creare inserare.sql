SET SERVEROUTPUT ON;

PROMPT ====== CLEANUP (drop fara erori) ======

BEGIN EXECUTE IMMEDIATE 'DROP TABLE nota CASCADE CONSTRAINTS'; EXCEPTION WHEN OTHERS THEN NULL; END;
/
BEGIN EXECUTE IMMEDIATE 'DROP TABLE inscriere CASCADE CONSTRAINTS'; EXCEPTION WHEN OTHERS THEN NULL; END;
/
BEGIN EXECUTE IMMEDIATE 'DROP TABLE material_didactic CASCADE CONSTRAINTS'; EXCEPTION WHEN OTHERS THEN NULL; END;
/
BEGIN EXECUTE IMMEDIATE 'DROP TABLE curs CASCADE CONSTRAINTS'; EXCEPTION WHEN OTHERS THEN NULL; END;
/
BEGIN EXECUTE IMMEDIATE 'DROP TABLE student CASCADE CONSTRAINTS'; EXCEPTION WHEN OTHERS THEN NULL; END;
/
BEGIN EXECUTE IMMEDIATE 'DROP TABLE profesor CASCADE CONSTRAINTS'; EXCEPTION WHEN OTHERS THEN NULL; END;
/
BEGIN EXECUTE IMMEDIATE 'DROP TABLE evaluare CASCADE CONSTRAINTS'; EXCEPTION WHEN OTHERS THEN NULL; END;
/
BEGIN EXECUTE IMMEDIATE 'DROP TABLE semestru CASCADE CONSTRAINTS'; EXCEPTION WHEN OTHERS THEN NULL; END;
/
BEGIN EXECUTE IMMEDIATE 'DROP TABLE departament CASCADE CONSTRAINTS'; EXCEPTION WHEN OTHERS THEN NULL; END;
/
BEGIN EXECUTE IMMEDIATE 'DROP TABLE program_studiu CASCADE CONSTRAINTS'; EXCEPTION WHEN OTHERS THEN NULL; END;
/

PROMPT ====== CREATE TABLES ======

CREATE TABLE program_studiu (
  id_program NUMBER PRIMARY KEY,
  denumire VARCHAR2(100) NOT NULL,
  nivel VARCHAR2(20) NOT NULL CHECK (nivel IN ('Licenta','Master'))
);

CREATE TABLE departament (
  id_departament NUMBER PRIMARY KEY,
  denumire VARCHAR2(100) NOT NULL UNIQUE
);

CREATE TABLE semestru (
  id_semestru NUMBER PRIMARY KEY,
  an_universitar VARCHAR2(9) NOT NULL,
  numar_semestru NUMBER NOT NULL CHECK (numar_semestru IN (1,2))
);

CREATE TABLE profesor (
  id_profesor NUMBER PRIMARY KEY,
  nume VARCHAR2(50) NOT NULL,
  prenume VARCHAR2(50) NOT NULL,
  email VARCHAR2(100) UNIQUE,
  grad_didactic VARCHAR2(30)
);

CREATE TABLE student (
  id_student NUMBER PRIMARY KEY,
  nume VARCHAR2(50) NOT NULL,
  prenume VARCHAR2(50) NOT NULL,
  email VARCHAR2(100) UNIQUE,
  data_nasterii DATE,
  data_inscriere DATE DEFAULT SYSDATE,
  id_program NUMBER NOT NULL,
  CONSTRAINT fk_student_program FOREIGN KEY (id_program)
    REFERENCES program_studiu(id_program)
);

CREATE TABLE evaluare (
  id_evaluare NUMBER PRIMARY KEY,
  tip_evaluare VARCHAR2(50) NOT NULL
);

CREATE TABLE curs (
  id_curs NUMBER PRIMARY KEY,
  denumire VARCHAR2(100) NOT NULL,
  credite NUMBER NOT NULL CHECK (credite > 0),
  id_profesor NUMBER NOT NULL,
  id_departament NUMBER NOT NULL,
  id_semestru NUMBER NOT NULL,
  CONSTRAINT fk_curs_profesor FOREIGN KEY (id_profesor) REFERENCES profesor(id_profesor),
  CONSTRAINT fk_curs_departament FOREIGN KEY (id_departament) REFERENCES departament(id_departament),
  CONSTRAINT fk_curs_semestru FOREIGN KEY (id_semestru) REFERENCES semestru(id_semestru)
);

CREATE TABLE inscriere (
  id_inscriere NUMBER PRIMARY KEY,
  id_student NUMBER NOT NULL,
  id_curs NUMBER NOT NULL,
  data_inscriere DATE DEFAULT SYSDATE,
  CONSTRAINT fk_inscriere_student FOREIGN KEY (id_student) REFERENCES student(id_student),
  CONSTRAINT fk_inscriere_curs FOREIGN KEY (id_curs) REFERENCES curs(id_curs),
  CONSTRAINT uq_student_curs UNIQUE (id_student, id_curs)
);

CREATE TABLE nota (
  id_nota NUMBER PRIMARY KEY,
  valoare NUMBER NOT NULL CHECK (valoare BETWEEN 1 AND 10),
  id_inscriere NUMBER NOT NULL UNIQUE,
  id_evaluare NUMBER NOT NULL,
  CONSTRAINT fk_nota_inscriere FOREIGN KEY (id_inscriere) REFERENCES inscriere(id_inscriere),
  CONSTRAINT fk_nota_evaluare FOREIGN KEY (id_evaluare) REFERENCES evaluare(id_evaluare)
);

CREATE TABLE material_didactic (
  id_material NUMBER PRIMARY KEY,
  titlu VARCHAR2(100) NOT NULL,
  tip VARCHAR2(30) NOT NULL,
  id_curs NUMBER NOT NULL,
  CONSTRAINT fk_material_curs FOREIGN KEY (id_curs) REFERENCES curs(id_curs)
);

PROMPT ====== INSERT DATA ======

-- PROGRAM_STUDIU (min 4)
INSERT INTO program_studiu VALUES (1, 'Informatica', 'Licenta');
INSERT INTO program_studiu VALUES (2, 'Matematica', 'Licenta');
INSERT INTO program_studiu VALUES (3, 'Informatica Aplicata', 'Master');
INSERT INTO program_studiu VALUES (4, 'Securitate Informatica', 'Master');

-- DEPARTAMENT (min 4)
INSERT INTO departament VALUES (1, 'Informatica');
INSERT INTO departament VALUES (2, 'Matematica');
INSERT INTO departament VALUES (3, 'Tehnologia Informatiei');
INSERT INTO departament VALUES (4, 'Sisteme Informationale');

-- SEMESTRU (min 4)
INSERT INTO semestru VALUES (1, '2024-2025', 1);
INSERT INTO semestru VALUES (2, '2024-2025', 2);
INSERT INTO semestru VALUES (3, '2023-2024', 1);
INSERT INTO semestru VALUES (4, '2023-2024', 2);

-- PROFESOR (min 4)
INSERT INTO profesor VALUES (1, 'Popescu', 'Ion', 'ion.popescu@uni.ro', 'Conferentiar');
INSERT INTO profesor VALUES (2, 'Ionescu', 'Maria', 'maria.ionescu@uni.ro', 'Profesor');
INSERT INTO profesor VALUES (3, 'Georgescu', 'Andrei', 'andrei.georgescu@uni.ro', 'Lector');
INSERT INTO profesor VALUES (4, 'Dumitrescu', 'Ana', 'ana.dumitrescu@uni.ro', 'Asistent');

-- STUDENT (min 4)
INSERT INTO student VALUES (1, 'Radu', 'Alex', 'alex.radu@student.ro', DATE '2002-05-10', SYSDATE, 1);
INSERT INTO student VALUES (2, 'Popa', 'Ioana', 'ioana.popa@student.ro', DATE '2001-03-22', SYSDATE, 1);
INSERT INTO student VALUES (3, 'Marin', 'Vlad', 'vlad.marin@student.ro', DATE '2000-11-15', SYSDATE, 2);
INSERT INTO student VALUES (4, 'Stan', 'Elena', 'elena.stan@student.ro', DATE '2002-01-08', SYSDATE, 3);

-- EVALUARE (min 4)
INSERT INTO evaluare VALUES (1, 'Examen');
INSERT INTO evaluare VALUES (2, 'Colocviu');
INSERT INTO evaluare VALUES (3, 'Proiect');
INSERT INTO evaluare VALUES (4, 'Test');

-- CURS (min 4)
INSERT INTO curs VALUES (1, 'Baze de date', 6, 1, 1, 1);
INSERT INTO curs VALUES (2, 'Programare Java', 5, 2, 1, 1);
INSERT INTO curs VALUES (3, 'Structuri de date', 5, 3, 3, 2);
INSERT INTO curs VALUES (4, 'Sisteme de operare', 6, 2, 4, 2);

-- INSCRIERE (tabel asociativ, min 8)
INSERT INTO inscriere VALUES (1, 1, 1, SYSDATE);
INSERT INTO inscriere VALUES (2, 1, 2, SYSDATE);
INSERT INTO inscriere VALUES (3, 2, 1, SYSDATE);
INSERT INTO inscriere VALUES (4, 2, 3, SYSDATE);
INSERT INTO inscriere VALUES (5, 3, 2, SYSDATE);
INSERT INTO inscriere VALUES (6, 3, 4, SYSDATE);
INSERT INTO inscriere VALUES (7, 4, 1, SYSDATE);
INSERT INTO inscriere VALUES (8, 4, 3, SYSDATE);

-- NOTA (min 4)
INSERT INTO nota VALUES (1, 9, 1, 1);
INSERT INTO nota VALUES (2, 8, 2, 2);
INSERT INTO nota VALUES (3, 10, 3, 1);
INSERT INTO nota VALUES (4, 7, 4, 3);

-- MATERIAL_DIDACTIC (min 4)
INSERT INTO material_didactic VALUES (1, 'Introducere BD', 'PDF', 1);
INSERT INTO material_didactic VALUES (2, 'Java Basics', 'PDF', 2);
INSERT INTO material_didactic VALUES (3, 'Structuri Liste', 'PPT', 3);
INSERT INTO material_didactic VALUES (4, 'Procese SO', 'PDF', 4);

COMMIT;

PROMPT ====== VERIFICARE RAPIDA ======
SELECT COUNT(*) AS nr_studenti FROM student;
SELECT COUNT(*) AS nr_cursuri FROM curs;
SELECT COUNT(*) AS nr_inscrieri FROM inscriere;
