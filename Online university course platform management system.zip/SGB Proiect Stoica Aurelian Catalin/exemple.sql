SET SERVEROUTPUT ON;

PROMPT =========================================================
PROMPT  EXEMPLE.SQL (FINAL) - RULARE SIGURA
PROMPT  Conditii:
PROMPT   1) Conectat ca PROIECT (nu SYS/SYSTEM)
PROMPT   2) Ai rulat inainte: creare_inserare.sql (F5)
PROMPT =========================================================

-- 0) Verificare conexiune: trebuie SESSION_USER = PROIECT
DECLARE
  v_user   VARCHAR2(128) := SYS_CONTEXT('USERENV','SESSION_USER');
  v_con    VARCHAR2(128) := SYS_CONTEXT('USERENV','CON_NAME');
BEGIN
  DBMS_OUTPUT.PUT_LINE('SESSION_USER='||v_user||', CON_NAME='||v_con);
  IF UPPER(v_user) <> 'PROIECT' THEN
    DBMS_OUTPUT.PUT_LINE('EROARE: nu esti conectat ca PROIECT. Deschide worksheet din conexiunea PROIECT@XEPDB1 si ruleaza din nou.');
    RAISE_APPLICATION_ERROR(-20011, 'Conexiune gresita: trebuie SESSION_USER=PROIECT.');
  END IF;
END;
/
-- 0.1) Verificare date existente (din creare_inserare.sql)
DECLARE
  v_students NUMBER; v_courses NUMBER; v_enroll NUMBER;
BEGIN
  SELECT COUNT(*) INTO v_students FROM student;
  SELECT COUNT(*) INTO v_courses  FROM curs;
  SELECT COUNT(*) INTO v_enroll   FROM inscriere;

  DBMS_OUTPUT.PUT_LINE('Verificare date: studenti='||v_students||', cursuri='||v_courses||', inscrieri='||v_enroll);

  IF v_students = 0 OR v_courses = 0 OR v_enroll = 0 THEN
    DBMS_OUTPUT.PUT_LINE('EROARE: nu exista date. Ruleaza mai intai creare_inserare.sql (F5), apoi ruleaza acest fisier.');
    RAISE_APPLICATION_ERROR(-20010, 'Date lipsa: ruleaza creare_inserare.sql inainte.');
  END IF;
END;
/

PROMPT ====== CLEANUP (pentru rerulare fara erori) ======
BEGIN EXECUTE IMMEDIATE 'DROP TRIGGER trg_nota_valoare'; EXCEPTION WHEN OTHERS THEN NULL; END;
/
BEGIN EXECUTE IMMEDIATE 'DROP TRIGGER trg_curs_insert'; EXCEPTION WHEN OTHERS THEN NULL; END;
/
BEGIN EXECUTE IMMEDIATE 'DROP PROCEDURE afisare_studenti_cursuri'; EXCEPTION WHEN OTHERS THEN NULL; END;
/
BEGIN EXECUTE IMMEDIATE 'DROP PROCEDURE afisare_note_student'; EXCEPTION WHEN OTHERS THEN NULL; END;
/
BEGIN EXECUTE IMMEDIATE 'DROP FUNCTION calculeaza_media_student'; EXCEPTION WHEN OTHERS THEN NULL; END;
/
BEGIN
  DELETE FROM nota WHERE id_nota IN (99, 100);
  DELETE FROM curs WHERE id_curs = 99;
  COMMIT;
EXCEPTION WHEN OTHERS THEN NULL;
END;
/

-- ===================================================
-- 11. Cereri SQL complexe
-- ===================================================

PROMPT ====== 11.1 JOIN + GROUP BY + HAVING + ORDER BY ======
SELECT c.denumire AS curs,
       COUNT(*) AS nr_studenti
FROM curs c
JOIN inscriere i ON i.id_curs = c.id_curs
GROUP BY c.denumire
HAVING COUNT(*) > 1
ORDER BY nr_studenti DESC;

PROMPT ====== 11.2 LEFT OUTER JOIN ======
SELECT s.nume, s.prenume, c.denumire AS curs, n.valoare AS nota
FROM student s
JOIN inscriere i ON i.id_student = s.id_student
JOIN curs c ON c.id_curs = i.id_curs
LEFT OUTER JOIN nota n ON n.id_inscriere = i.id_inscriere
ORDER BY s.nume, s.prenume, c.denumire;

PROMPT ====== 11.3 SUBCERERE NESINCRONIZATA ======
SELECT DISTINCT s.nume, s.prenume
FROM student s
JOIN inscriere i ON i.id_student = s.id_student
JOIN nota n ON n.id_inscriere = i.id_inscriere
WHERE n.valoare > (SELECT AVG(valoare) FROM nota);

-- ===================================================
-- 12. Procedura cu cursor
-- ===================================================
/*
Problema:
Sa se afiseze pentru fiecare curs lista studentilor inscrisi la acel curs.
*/
PROMPT ====== 12. PROCEDURA CU CURSOR ======
CREATE OR REPLACE PROCEDURE afisare_studenti_cursuri IS
  CURSOR c_cursuri IS SELECT id_curs, denumire FROM curs ORDER BY id_curs;
  CURSOR c_studenti(p_id_curs NUMBER) IS
    SELECT s.nume, s.prenume
    FROM student s
    JOIN inscriere i ON i.id_student = s.id_student
    WHERE i.id_curs = p_id_curs
    ORDER BY s.nume, s.prenume;
  v_gasit BOOLEAN;
BEGIN
  FOR r IN c_cursuri LOOP
    DBMS_OUTPUT.PUT_LINE('Curs: ' || r.denumire);
    v_gasit := FALSE;

    FOR st IN c_studenti(r.id_curs) LOOP
      DBMS_OUTPUT.PUT_LINE('   Student: ' || st.nume || ' ' || st.prenume);
      v_gasit := TRUE;
    END LOOP;

    IF NOT v_gasit THEN
      DBMS_OUTPUT.PUT_LINE('   Nu exista studenti inscrisi.');
    END IF;

    DBMS_OUTPUT.PUT_LINE('-----------------------------------');
  END LOOP;
END;
/
BEGIN afisare_studenti_cursuri; END;
/

-- ===================================================
-- 13. Functie (3 tabele intr-un SELECT) + exceptii
-- ===================================================
/*
Problema:
Sa se calculeze media notelor unui student folosind STUDENT, INSCRIERE, NOTA.
*/
PROMPT ====== 13. FUNCTIE (3 TABELE) + EXCEPTII ======
CREATE OR REPLACE FUNCTION calculeaza_media_student(p_id_student NUMBER)
RETURN NUMBER IS
  v_media NUMBER;
BEGIN
  SELECT AVG(n.valoare)
    INTO v_media
    FROM student s
    JOIN inscriere i ON i.id_student = s.id_student
    JOIN nota n ON n.id_inscriere = i.id_inscriere
   WHERE s.id_student = p_id_student;

  RETURN v_media;

EXCEPTION
  WHEN NO_DATA_FOUND THEN
    DBMS_OUTPUT.PUT_LINE('NO_DATA_FOUND: studentul nu are note sau nu exista date.');
    RETURN NULL;
  WHEN TOO_MANY_ROWS THEN
    DBMS_OUTPUT.PUT_LINE('TOO_MANY_ROWS: situatie neasteptata.');
    RETURN NULL;
  WHEN OTHERS THEN
    DBMS_OUTPUT.PUT_LINE('Eroare: ' || SQLERRM);
    RETURN NULL;
END;
/

DECLARE v NUMBER;
BEGIN
  v := calculeaza_media_student(1);
  DBMS_OUTPUT.PUT_LINE('Media studentului 1: ' || NVL(TO_CHAR(v),'N/A'));
  v := calculeaza_media_student(999);
  DBMS_OUTPUT.PUT_LINE('Media studentului 999: ' || NVL(TO_CHAR(v),'N/A'));
END;
/

-- ===================================================
-- 14. Procedura (5+ tabele intr-un SELECT) + exceptii
-- ===================================================
/*
Problema:
Sa se afiseze pentru un student lista cursurilor, profesorul, tipul evaluarii si nota (daca exista),
folosind intr-un singur SELECT 5+ tabele.
*/
PROMPT ====== 14. PROCEDURA (5+ TABELE) + EXCEPTII ======
CREATE OR REPLACE PROCEDURE afisare_note_student(p_id_student NUMBER) IS
  v_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO v_cnt FROM student WHERE id_student = p_id_student;
  IF v_cnt = 0 THEN
    RAISE NO_DATA_FOUND;
  END IF;

  FOR r IN (
    SELECT s.nume||' '||s.prenume AS student,
           c.denumire AS curs,
           p.nume||' '||p.prenume AS profesor,
           NVL(e.tip_evaluare,'-') AS tip_evaluare,
           NVL(TO_CHAR(n.valoare),'-') AS nota
    FROM student s
    JOIN inscriere i ON i.id_student = s.id_student
    JOIN curs c ON c.id_curs = i.id_curs
    JOIN profesor p ON p.id_profesor = c.id_profesor
    LEFT JOIN nota n ON n.id_inscriere = i.id_inscriere
    LEFT JOIN evaluare e ON e.id_evaluare = n.id_evaluare
    WHERE s.id_student = p_id_student
    ORDER BY c.denumire
  ) LOOP
    DBMS_OUTPUT.PUT_LINE(r.student||' | '||r.curs||' | '||r.profesor||' | '||r.tip_evaluare||' | '||r.nota);
  END LOOP;

EXCEPTION
  WHEN NO_DATA_FOUND THEN
    DBMS_OUTPUT.PUT_LINE('NO_DATA_FOUND: nu exista student cu id=' || p_id_student);
  WHEN TOO_MANY_ROWS THEN
    DBMS_OUTPUT.PUT_LINE('TOO_MANY_ROWS: prea multe randuri (neasteptat).');
  WHEN OTHERS THEN
    DBMS_OUTPUT.PUT_LINE('Eroare: ' || SQLERRM);
END;
/
BEGIN
  afisare_note_student(1);
  afisare_note_student(999);
END;
/

-- ===================================================
-- 15. Trigger statement-level
-- ===================================================
PROMPT ====== 15. TRIGGER STATEMENT-LEVEL ======
CREATE OR REPLACE TRIGGER trg_curs_insert
AFTER INSERT ON curs
BEGIN
  DBMS_OUTPUT.PUT_LINE('TRIGGER 15: Un curs a fost adaugat in baza de date.');
END;
/
-- Declansare garantata (FK-uri valide preluate din cursul existent id=1)
INSERT INTO curs (id_curs, denumire, credite, id_profesor, id_departament, id_semestru)
SELECT 99, 'Test Trigger 15', credite, id_profesor, id_departament, id_semestru
FROM curs
WHERE id_curs = 1;

-- ===================================================
-- 16. Trigger row-level
-- ===================================================
PROMPT ====== 16. TRIGGER ROW-LEVEL ======
CREATE OR REPLACE TRIGGER trg_nota_valoare
BEFORE INSERT OR UPDATE ON nota
FOR EACH ROW
BEGIN
  IF :NEW.valoare < 1 OR :NEW.valoare > 10 THEN
    RAISE_APPLICATION_ERROR(-20001, 'TRIGGER 16: Nota trebuie sa fie intre 1 si 10!');
  END IF;
END;
/
-- Declansare garantata (valid): alege automat o inscriere fara nota
INSERT INTO nota (id_nota, valoare, id_inscriere, id_evaluare)
SELECT 99, 9, i.id_inscriere, 1
FROM inscriere i
LEFT JOIN nota n ON n.id_inscriere = i.id_inscriere
WHERE n.id_inscriere IS NULL
  AND ROWNUM = 1;

COMMIT;

PROMPT ====== FINAL: verificare triggere ======
SELECT trigger_name, status FROM user_triggers ORDER BY trigger_name;

PROMPT ====== DONE ======
